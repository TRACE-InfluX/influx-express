module.exports = {
  apiKey: "AIzaSyC14SfEnKw-qV1SaTqpIYA5GogIfqFpQgk",
  authDomain: "influx-trace.firebaseapp.com",
  databaseURL: "https://influx-trace.firebaseio.com",
  projectId: "influx-trace",
  storageBucket: "influx-trace.appspot.com",
  messagingSenderId: "876821038783"
}