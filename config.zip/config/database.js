module.exports = {
  url: 'mongodb+srv://sudo:am1VV9yJYOWF7ZDI@influx-trace-7n6ui.mongodb.net/test?retryWrites=true',
  name: 'influx-dev'
}