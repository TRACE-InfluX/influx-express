module.exports = {
  type: 'service_account',
  project_id: 'influx-trace',
  private_key_id: '9d8270b565005c250a36275272df858445fc7542',
  private_key: '-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCiIwy4Vp42JlR+\nQbuoZ/9hXdeWDxjWMvZbw6nbR2rrTe3pw3HyNPBEFUUL0QIORKZF/QEX0qKPdPrU\nQj8pBmUX00QjdPlb7xWwmksUB/OMsTySsvKsBxXK19dAN9Qsq62OBdIryQP6VDon\n+hemBnO4Y2mvS+e52cPARLYM+ipwMbW9sB49enXyDkaNRfUJ3sOhYEkOlb6k7DZh\nc1waupMhGpLLO505FmzrcMTTHQV8DMnXcBZpAiID4mv+XcLHkJmd+/jE/DoIIMGP\n2WDyl7pEYfddpYPC/m+N7NCoRx51jJVsTLfalU5E1YaXtOT5efa5tVWc3Z6B+07a\n48EIyLnZAgMBAAECggEADKka/av517WfhGpimnBgfzxiMLwGDvfUx+6b7V0CytP/\nf3D9DVI37sEQbq9H71BKAY4Tj0Yp3nTef0ObBfuTWkxrdi9Up2qgcXVi5nIGgRZ3\n6eaiT2+QMpIvIzsYzNItD7mBo1yjfGEmV2fOf+7iC2Rr5L3THu6TvAhBhPrl5HPF\naxXMK43QG33nVZhULSStud3cBbEHma3hnDnRtft6fPH9O1/NiB+D6PQNGK9LRkNU\neP5lunMWr1lyBEYjrXCX1ODOdMf6Kd41xnfd7jK+EssXDoD49YeNvE7U62qmSOjm\n1RwKqnZ8qJQOXM7nAbyLUjhBMYI+BSr19/HbhDWMWQKBgQDT8RIPfCINDf5m7uGv\nUeeR6LsmRrlH86srzxSojzk3BNpJ2n20XuBytNVLp/UNr0hskPf2DxdHvnYKsp4+\n9A90I/OqD2bCimmKYmFWijEMlYDIufLZqxSgsovjsI4BvadpxKVT/edDFfsc4QZk\neRCOPUn4DZG1T4oeUsd7tHPOBQKBgQDD14MOgzdCrpXY/ZR7eKRV1i4iILobdmBR\nLQYi4lz+V+gIcNPgAHPBgx8iluoKLlWfndGCSB4rw5p7+RMu5+A6sECEqAFsF99N\njfvilcojcFdFuJTm2RT9qWad93gyBplr4r0v3IWq+5eohquCfuIqCtXL+boJyt4V\n/5o7+LVwxQKBgQDJZv6opGefTDsDCeKBPi32o9ikqPSNAWsZ+HFDNMdEF2JwaCao\nbriPiHRgrrzaQkVqleBsfS68SKvXwqFKZZcB4OA+LOCT4gAlNxQUrsGpmbCGDt5O\nJps1kjYJKs/nq5gZlHsfc9p+D7dPXC887ybiZC+UfyCF0Y4I/tT+Ix8hGQKBgAs2\nQ2KJUJiYtit+GQoYlg/z+yApD36TAGClWzyUCQ7mqXoSO48Pd5EUmKu6SBvdGznQ\nJzZ2OoP25tlCIT8GN2gkvwzZMXumwjoGbu1B9hihTd3H+35b3z/GewGAMXlrt0zd\n5kbfMSfgz4Xub9NAwGH3zNWormXxH1XTFFlqm7ihAoGANy+SJRg3/PASW9eG6++d\n02eURxOI9Jvdjub0Ba0T3XTKE+JbPLldnvj/tCy5DeLk59YgBF8IK1UFC4JNd/5T\nz8HDqdiNIDMm9eGLfP3VB0/giOcQ3ikGylW42iegpWv+WakWDw7rF2fyJEuH0Pdp\n5hHvZgZANUm9K3AyIA9p13U=\n-----END PRIVATE KEY-----\n',
  client_email: 'firebase-adminsdk-cwiqe@influx-trace.iam.gserviceaccount.com',
  client_id: '107589046689013314298',
  auth_uri: 'https://accounts.google.com/o/oauth2/auth',
  token_uri: 'https://oauth2.googleapis.com/token',
  auth_provider_x509_cert_url: 'https://www.googleapis.com/oauth2/v1/certs',
  client_x509_cert_url: 'https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-cwiqe%40influx-trace.iam.gserviceaccount.com'
}
