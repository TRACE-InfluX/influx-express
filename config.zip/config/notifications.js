module.exports = {
  url: 'https://discordapp.com/api/webhooks/576469298814517258/erfUtCFJFHJzzrexMm48QZsvz5sgQELaMXhwfWP-9kM6eMIP68iTuJ7_A2kl9EBSnZlY',
  server: 'Host of Swag /dab',
  enable: ['Error','Info']
}